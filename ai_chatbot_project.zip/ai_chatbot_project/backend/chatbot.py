from groq import Groq
import os

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "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")

client = Groq(api_key=GROQ_API_KEY)

SYSTEM_PROMPT = """You are MindBot - an intelligent AI assistant specializing in:

1. **Mental Health Support** - Empathetic, non-diagnostic support
2. **AI & Technology Education** - Explaining Chatbots, RAG, Agentic AI, Langchain
3. **Healthcare AI** - AI applications in healthcare
4. **Real-world AI Projects** - Practical guidance on building AI systems

## Your Knowledge Areas:
- What is a Chatbot? (history, types, use cases)
- What is RAG (Retrieval Augmented Generation)?
- What is Agentic AI? (autonomous agents, tools, planning)
- Agentic AI new projects and developments
- AI in Healthcare (diagnostics, patient care, drug discovery)
- What is Langchain? (framework, components, use cases)
- How to use Langchain? (step-by-step guidance)
- Chatbot projects for the real world

## Rules:
- Be empathetic and supportive for mental health topics
- Never give medical diagnoses - recommend professionals
- Be educational and clear for technical topics
- Use examples and analogies to explain complex concepts
- If context is provided from documents, use it to enhance your answer
- Format responses with markdown for clarity
- Keep responses concise but comprehensive

## Style:
- Warm, friendly tone
- Use emojis sparingly but effectively
- Structure longer answers with headers
- Always end with an encouraging note or follow-up question
"""


class Chatbot:
    def __init__(self):
        self.model = "llama-3.3-70b-versatile"

    def get_response(self, user_message: str, conversation_history: list = None, rag_context: str = "") -> str:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        # Add RAG context if available
        if rag_context:
            context_msg = f"""## Relevant Knowledge Base Information:
{rag_context}

Use this information to enhance your response if relevant."""
            messages.append({"role": "system", "content": context_msg})

        # Add conversation history (last 10 messages for context window)
        if conversation_history:
            for msg in conversation_history[-10:]:
                messages.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })

        # Add current message
        messages.append({"role": "user", "content": user_message})

        try:
            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
                max_tokens=1024
            )
            return response.choices[0].message.content

        except Exception as e:
            return f"⚠️ I'm having trouble connecting right now. Error: {str(e)}\n\nPlease check your API key and try again."
