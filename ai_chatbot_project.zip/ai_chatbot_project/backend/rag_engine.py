import os
import json
import numpy as np
from typing import List, Dict, Any
import hashlib

# We'll use sentence-transformers for embeddings and FAISS for vector search
# Fallback to simple keyword search if dependencies not available

try:
    from sentence_transformers import SentenceTransformer
    import faiss
    RAG_AVAILABLE = True
except ImportError:
    RAG_AVAILABLE = False
    print("⚠️  RAG dependencies not installed. Using keyword search fallback.")


# ─── Default Knowledge Base ───────────────────────────────────────────────────

DEFAULT_KNOWLEDGE = [
    {
        "id": "chatbot_basics",
        "title": "What is a Chatbot?",
        "content": """A chatbot is a software application that simulates human conversation through text or voice interactions. 
Chatbots use Natural Language Processing (NLP) to understand user input and generate appropriate responses.

Types of Chatbots:
1. Rule-based chatbots - Follow predefined rules and decision trees
2. AI/ML chatbots - Use machine learning to understand context and intent
3. Hybrid chatbots - Combine rules with AI capabilities

Use Cases:
- Customer service automation
- Mental health support (like this bot!)
- E-commerce assistance
- Healthcare information
- Educational tutoring

Modern chatbots use Large Language Models (LLMs) like GPT, Llama, or Claude for natural conversation."""
    },
    {
        "id": "rag_explained",
        "title": "What is RAG (Retrieval Augmented Generation)?",
        "content": """RAG stands for Retrieval Augmented Generation - a technique that enhances LLM responses with external knowledge.

How RAG Works:
1. Document Ingestion - Load documents into the system
2. Chunking - Split documents into smaller pieces
3. Embedding - Convert text chunks to vector representations
4. Vector Storage - Store embeddings in a vector database (FAISS, Pinecone, Chroma)
5. Query Processing - Convert user query to embedding
6. Retrieval - Find most similar document chunks
7. Generation - LLM generates response using retrieved context

Why RAG?
- LLMs have knowledge cutoff dates
- RAG provides up-to-date, specific information
- Reduces hallucinations by grounding responses in facts
- Allows domain-specific knowledge without fine-tuning

Tools: LangChain, LlamaIndex, Haystack, ChromaDB, FAISS, Pinecone"""
    },
    {
        "id": "agentic_ai",
        "title": "What is Agentic AI?",
        "content": """Agentic AI refers to AI systems that can autonomously plan, reason, and take actions to complete complex tasks.

Key Characteristics:
1. Autonomy - Can make decisions without constant human input
2. Tool Use - Can use external tools (search, code execution, APIs)
3. Planning - Breaks complex tasks into subtasks
4. Memory - Maintains context across interactions
5. Reflection - Can evaluate and improve its own outputs

Types of AI Agents:
- ReAct Agents (Reasoning + Acting)
- Plan-and-Execute Agents
- Multi-Agent Systems
- AutoGPT style agents

Popular Frameworks:
- LangChain Agents
- CrewAI (multi-agent collaboration)
- AutoGen (Microsoft)
- LlamaIndex Agents

New Agentic AI Projects (2024-2025):
- Devin AI - Autonomous software engineer
- Claude Computer Use - AI that controls computers
- OpenAI Operator - Web browsing agent
- CrewAI - Multi-agent task automation
- Manus AI - General purpose AI agent"""
    },
    {
        "id": "ai_healthcare",
        "title": "AI in Healthcare",
        "content": """Artificial Intelligence is revolutionizing healthcare across multiple domains.

Diagnostic AI:
- Medical image analysis (X-rays, MRI, CT scans)
- Pathology slide analysis
- Early disease detection (cancer, diabetic retinopathy)
- ECG interpretation

Clinical Decision Support:
- Drug interaction checking
- Treatment recommendation systems
- Risk stratification for patients
- Clinical note summarization

Drug Discovery:
- AlphaFold - Protein structure prediction
- Molecular design optimization
- Clinical trial optimization
- Target identification

Patient Care:
- Mental health chatbots and support
- Medication adherence monitoring
- Remote patient monitoring
- Personalized treatment plans

Administrative:
- Medical coding automation
- Insurance claim processing
- Appointment scheduling
- Electronic health record management

Challenges:
- Data privacy (HIPAA compliance)
- Bias in AI models
- Regulatory approval (FDA clearance)
- Integration with existing systems

Pakistan Healthcare AI:
- Shaukat Khanum uses AI for cancer detection
- Aga Khan Health Services digital initiatives
- Telemedicine platforms with AI triage"""
    },
    {
        "id": "langchain_what",
        "title": "What is LangChain?",
        "content": """LangChain is an open-source framework for building applications powered by Large Language Models (LLMs).

Core Components:
1. Models - Interface with LLMs (OpenAI, Groq, Anthropic, Hugging Face)
2. Prompts - Prompt templates and management
3. Chains - Sequences of LLM calls and actions
4. Agents - Autonomous AI with tool access
5. Memory - Conversation history management
6. Retrievers - Document retrieval for RAG
7. Vector Stores - Embedding storage (FAISS, Chroma, Pinecone)

Why LangChain?
- Abstracts away API complexities
- Makes it easy to switch between LLM providers
- Built-in support for RAG pipelines
- Extensive tool integrations
- Large community and ecosystem

LangChain Ecosystem:
- LangChain Core - Main framework
- LangChain Hub - Prompt sharing
- LangSmith - Debugging and monitoring
- LangServe - Deploy chains as APIs
- LangGraph - Build agent workflows as graphs"""
    },
    {
        "id": "langchain_how",
        "title": "How to Use LangChain?",
        "content": """Getting started with LangChain - Step by Step Guide

Installation:
pip install langchain langchain-groq langchain-community faiss-cpu sentence-transformers

Basic LLM Chain:
```python
from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate

llm = ChatGroq(model="llama3-70b-8192", api_key="your_key")
prompt = ChatPromptTemplate.from_template("Answer this: {question}")
chain = prompt | llm
result = chain.invoke({"question": "What is AI?"})
```

Building a RAG Pipeline:
```python
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.chains import RetrievalQA

# 1. Load documents
from langchain_community.document_loaders import TextLoader
docs = TextLoader("my_doc.txt").load()

# 2. Create embeddings and vector store
embeddings = HuggingFaceEmbeddings()
vectorstore = FAISS.from_documents(docs, embeddings)

# 3. Create RAG chain
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    retriever=vectorstore.as_retriever()
)
result = qa_chain.invoke("Your question here")
```

Building an Agent:
```python
from langchain.agents import create_react_agent, AgentExecutor
from langchain.tools import DuckDuckGoSearchRun

tools = [DuckDuckGoSearchRun()]
agent = create_react_agent(llm, tools, prompt)
executor = AgentExecutor(agent=agent, tools=tools)
result = executor.invoke({"input": "Search for latest AI news"})
```"""
    },
    {
        "id": "real_world_chatbot",
        "title": "Chatbot Project for Real World",
        "content": """Building production-ready chatbots requires more than just connecting to an LLM.

Architecture Components:
1. Frontend - React/Next.js or Streamlit UI
2. Backend API - Flask/FastAPI server
3. LLM Integration - Groq/OpenAI/Anthropic
4. RAG Pipeline - For domain knowledge
5. Memory System - Conversation history
6. Crisis Detection - For mental health apps
7. Authentication - User management
8. Database - Chat history storage
9. Monitoring - LangSmith or custom logging

Best Practices:
- Always validate user input
- Implement rate limiting
- Store API keys in environment variables (never in code!)
- Use streaming responses for better UX
- Add fallback responses for API failures
- Log conversations for improvement
- A/B test different prompts
- Monitor hallucinations

Deployment Options:
- Local: Flask + Streamlit
- Cloud: AWS, GCP, Azure
- Containers: Docker + Kubernetes
- Serverless: Vercel, Railway, Render

Mental Health Chatbot Specifics:
- Crisis detection is mandatory
- Always recommend professional help
- Maintain user privacy
- Follow HIPAA guidelines if in healthcare
- Include emergency contact information
- Regular prompt auditing for safety"""
    },
    {
        "id": "mental_health_support",
        "title": "Mental Health Support & Resources",
        "content": """Mental Health awareness and support resources.

Common Mental Health Conditions:
- Anxiety Disorders - Excessive worry, panic attacks
- Depression - Persistent sadness, loss of interest
- PTSD - Trauma-related stress responses
- OCD - Obsessive thoughts and compulsive behaviors
- Bipolar Disorder - Extreme mood swings

Coping Strategies:
1. Mindfulness & Meditation - Apps: Headspace, Calm
2. Exercise - 30 minutes daily reduces anxiety by 48%
3. Sleep hygiene - 7-9 hours, consistent schedule
4. Social connection - Talk to trusted people
5. Professional therapy - CBT, DBT, EMDR
6. Journaling - Writing helps process emotions
7. Breathing exercises - 4-7-8 breathing technique

Pakistan Mental Health Resources:
- Umang Helpline: 0317-4288665 (24/7)
- Rozan Counseling Center: 051-2890505
- Fountain House Lahore: 042-35761999
- Edhi Foundation: 115

Warning Signs to Seek Help:
- Thoughts of self-harm or suicide
- Inability to perform daily activities
- Substance abuse to cope
- Severe mood swings affecting relationships

Remember: Seeking help is a sign of strength, not weakness."""
    }
]


class RAGEngine:
    def __init__(self):
        self.knowledge_chunks = []
        self.embeddings_model = None
        self.index = None
        self.ready = False
        self._setup()

    def _setup(self):
        """Initialize the embedding model and FAISS index"""
        if RAG_AVAILABLE:
            try:
                self.embeddings_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("✅ RAG Engine initialized with FAISS + SentenceTransformers")
            except Exception as e:
                print(f"⚠️ Could not load embedding model: {e}")
        else:
            print("📝 Using keyword-based search (install sentence-transformers for better RAG)")

    def load_default_knowledge(self):
        """Load the built-in knowledge base"""
        for doc in DEFAULT_KNOWLEDGE:
            self._add_chunk(doc["title"], doc["content"], "built-in")
        self._build_index()
        self.ready = True
        print(f"✅ Loaded {len(self.knowledge_chunks)} knowledge chunks")

    def _add_chunk(self, title: str, content: str, source: str):
        """Add a chunk to the knowledge store"""
        chunk_id = hashlib.md5(content.encode()).hexdigest()[:8]
        self.knowledge_chunks.append({
            "id": chunk_id,
            "title": title,
            "content": content,
            "source": source
        })

    def _build_index(self):
        """Build FAISS index from current chunks"""
        if not RAG_AVAILABLE or not self.embeddings_model:
            return

        try:
            texts = [f"{c['title']}\n{c['content']}" for c in self.knowledge_chunks]
            embeddings = self.embeddings_model.encode(texts, show_progress_bar=False)
            
            dim = embeddings.shape[1]
            self.index = faiss.IndexFlatL2(dim)
            self.index.add(embeddings.astype(np.float32))
            print(f"✅ FAISS index built with {len(texts)} vectors (dim={dim})")
        except Exception as e:
            print(f"⚠️ FAISS index build failed: {e}")

    def add_document(self, file_path: str) -> Dict:
        """Add an external document to the knowledge base"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Simple chunking by paragraphs
            paragraphs = [p.strip() for p in content.split('\n\n') if len(p.strip()) > 100]
            filename = os.path.basename(file_path)

            for i, para in enumerate(paragraphs):
                self._add_chunk(
                    title=f"{filename} - Section {i+1}",
                    content=para,
                    source=filename
                )

            # Rebuild index
            self._build_index()

            return {"chunks": len(paragraphs), "source": filename}
        except Exception as e:
            return {"error": str(e)}

    def query(self, query_text: str, top_k: int = 3) -> Dict:
        """Retrieve relevant chunks for a query"""
        if not self.knowledge_chunks:
            return {"context": "", "sources": []}

        if RAG_AVAILABLE and self.index and self.embeddings_model:
            return self._vector_search(query_text, top_k)
        else:
            return self._keyword_search(query_text, top_k)

    def _vector_search(self, query_text: str, top_k: int) -> Dict:
        """FAISS vector similarity search"""
        try:
            query_embedding = self.embeddings_model.encode([query_text])
            distances, indices = self.index.search(
                query_embedding.astype(np.float32), 
                min(top_k, len(self.knowledge_chunks))
            )

            results = []
            for idx, dist in zip(indices[0], distances[0]):
                if idx < len(self.knowledge_chunks) and dist < 2.0:  # threshold
                    chunk = self.knowledge_chunks[idx]
                    results.append(chunk)

            if not results:
                return {"context": "", "sources": []}

            context = "\n\n---\n\n".join([
                f"**{r['title']}**\n{r['content']}" for r in results
            ])

            return {
                "context": context,
                "sources": [{"title": r["title"], "source": r["source"]} for r in results]
            }
        except Exception as e:
            return self._keyword_search(query_text, top_k)

    def _keyword_search(self, query_text: str, top_k: int) -> Dict:
        """Simple keyword-based fallback search"""
        query_words = set(query_text.lower().split())
        scores = []

        for i, chunk in enumerate(self.knowledge_chunks):
            chunk_text = (chunk["title"] + " " + chunk["content"]).lower()
            score = sum(1 for word in query_words if word in chunk_text)
            scores.append((score, i))

        scores.sort(reverse=True)
        top_results = [self.knowledge_chunks[i] for score, i in scores[:top_k] if score > 0]

        if not top_results:
            return {"context": "", "sources": []}

        context = "\n\n---\n\n".join([
            f"**{r['title']}**\n{r['content']}" for r in top_results
        ])

        return {
            "context": context,
            "sources": [{"title": r["title"], "source": r["source"]} for r in top_results]
        }

    def get_stats(self) -> Dict:
        """Return knowledge base statistics"""
        sources = {}
        for chunk in self.knowledge_chunks:
            src = chunk["source"]
            sources[src] = sources.get(src, 0) + 1

        return {
            "total_chunks": len(self.knowledge_chunks),
            "sources": sources,
            "rag_mode": "FAISS Vector Search" if (RAG_AVAILABLE and self.index) else "Keyword Search",
            "ready": self.ready
        }

    def is_ready(self) -> bool:
        return self.ready
