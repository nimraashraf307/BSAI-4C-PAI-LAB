from flask import Flask, request, jsonify
from flask_cors import CORS
from chatbot import Chatbot
from crisis_detector import detect_crisis
from rag_engine import RAGEngine
import os

app = Flask(__name__)
CORS(app)

# Initialize components
chatbot = Chatbot()
rag = RAGEngine()

# Load default knowledge base on startup
rag.load_default_knowledge()


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_message = data.get("message", "")
    conversation_history = data.get("history", [])
    use_rag = data.get("use_rag", True)

    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    # Crisis detection first
    if detect_crisis(user_message):
        return jsonify({
            "response": (
                "🚨 I'm concerned about what you've shared. Please know you are not alone.\n\n"
                "**Immediate Help:**\n"
                "- 📞 Pakistan Umang Helpline: 0317-4288665\n"
                "- 📞 Rozan Counseling: 051-2890505\n"
                "- 🌍 International: Befrienders Worldwide\n\n"
                "Please reach out to a trusted person or mental health professional right away. "
                "Your life has value and help is available."
            ),
            "is_crisis": True,
            "sources": []
        })

    # RAG context retrieval
    rag_context = ""
    sources = []
    if use_rag:
        rag_result = rag.query(user_message)
        rag_context = rag_result.get("context", "")
        sources = rag_result.get("sources", [])

    # Get LLM response
    reply = chatbot.get_response(
        user_message=user_message,
        conversation_history=conversation_history,
        rag_context=rag_context
    )

    return jsonify({
        "response": reply,
        "is_crisis": False,
        "sources": sources
    })


@app.route("/upload", methods=["POST"])
def upload_document():
    """Upload a document to the RAG knowledge base"""
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    # Save file temporarily
    upload_path = os.path.join("../data", file.filename)
    file.save(upload_path)

    # Add to RAG
    result = rag.add_document(upload_path)

    return jsonify({
        "message": f"Document '{file.filename}' added to knowledge base",
        "chunks_added": result.get("chunks", 0)
    })


@app.route("/knowledge-base", methods=["GET"])
def get_knowledge_base():
    """Get info about current knowledge base"""
    return jsonify(rag.get_stats())


@app.route("/clear-history", methods=["POST"])
def clear_history():
    return jsonify({"message": "History cleared"})


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "running", "rag_enabled": rag.is_ready()})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
