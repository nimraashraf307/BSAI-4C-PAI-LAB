"""
Crisis Detection Module
Detects mental health crisis situations in user messages
"""

CRISIS_KEYWORDS = [
    # Suicidal ideation
    "suicide", "suicidal", "kill myself", "end my life", "take my life",
    "want to die", "wish i was dead", "better off dead", "no reason to live",
    "can't go on", "cannot go on", "don't want to live",
    
    # Self-harm
    "self harm", "self-harm", "selfharm", "hurt myself", "cut myself",
    "cutting myself", "harm myself",
    
    # Urdu/Roman Urdu keywords
    "khud kushi", "jaan dena chahta", "marna chahta", "marna chahti",
    "zindagi khatam", "jeena nahi chahta", "jeena nahi chahti"
]

CRISIS_PHRASES = [
    "i want to die",
    "i want to kill",
    "i don't want to be here anymore",
    "i dont want to be here",
    "life is not worth",
    "nobody would miss me",
    "everyone would be better without me"
]


def detect_crisis(message: str) -> bool:
    """
    Returns True if the message contains crisis-related content
    """
    if not message:
        return False
    
    message_lower = message.lower().strip()
    
    # Check keywords
    for keyword in CRISIS_KEYWORDS:
        if keyword in message_lower:
            return True
    
    # Check phrases
    for phrase in CRISIS_PHRASES:
        if phrase in message_lower:
            return True
    
    return False


def get_crisis_level(message: str) -> str:
    """
    Returns crisis level: 'none', 'low', 'medium', 'high'
    """
    if not detect_crisis(message):
        return "none"
    
    message_lower = message.lower()
    
    high_indicators = ["suicide", "kill myself", "end my life", "want to die", "self harm"]
    if any(ind in message_lower for ind in high_indicators):
        return "high"
    
    return "medium"
