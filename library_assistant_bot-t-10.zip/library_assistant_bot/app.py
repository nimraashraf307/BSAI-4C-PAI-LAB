from flask import Flask, render_template, request, jsonify
from datetime import datetime, timedelta

app = Flask(__name__)

# =========================
# BOOKS DATABASE
# =========================

books = {

    "python": "Python Programming by John Zelle - Available",

    "database": "Database System Concepts by Silberschatz - Available",

    "ai": "Artificial Intelligence Basics - Issued",

    "machine learning": "Hands-On Machine Learning - Available",

    "web development": "Flask Web Development - Available",

    "java": "Java Programming by James Gosling - Available",

    "c++": "Object Oriented Programming with C++ - Available",

    "html": "HTML & CSS Complete Guide - Available",

    "css": "CSS Mastery - Available",

    "javascript": "JavaScript for Beginners - Issued",

    "react": "React JS Complete Course - Available",

    "django": "Django Web Framework - Available",

    "data science": "Data Science Handbook - Available",

    "computer networks": "Computer Networking by Kurose - Available",

    "operating system": "Operating System Concepts - Issued",

    "software engineering": "Software Engineering by Pressman - Available",

    "cyber security": "Cyber Security Essentials - Available",

    "cloud computing": "Cloud Computing Concepts - Available",

    "android": "Android App Development - Available",

    "sql": "SQL Database Programming - Available",

    "mysql": "MySQL for Beginners - Available",

    "mongodb": "MongoDB Complete Guide - Available",

    "php": "PHP and MySQL Web Development - Available",

    "laravel": "Laravel Framework Basics - Available",

    "nodejs": "Node.js Backend Development - Available",

    "compiler": "Compiler Design Principles - Available",

    "discrete mathematics": "Discrete Mathematics and Applications - Available",

    "calculus": "Engineering Calculus - Available",

    "physics": "University Physics - Available",

    "chemistry": "Basic Chemistry Concepts - Available",

    "english": "English Grammar and Composition - Available",

    "statistics": "Statistics for Data Analysis - Available",

    "deep learning": "Deep Learning with Python - Available",

    "computer graphics": "Computer Graphics Principles - Available",

    "digital logic": "Digital Logic Design - Available",

    "assembly language": "Assembly Language Programming - Available",

    "network security": "Network Security Essentials - Available",

    "ethical hacking": "Ethical Hacking Guide - Available",

    "iot": "Internet of Things Fundamentals - Available"
}

# =========================
# LIBRARY INFO
# =========================

opening_hours = (
    "Library is open Monday to Saturday "
    "from 8:00 AM to 8:00 PM"
)

due_date = (
    datetime.now() + timedelta(days=7)
).strftime("%d %B %Y")


# =========================
# CHATBOT FUNCTION
# =========================

def chatbot_response(message):

    msg = message.lower().strip()

    # Greeting
    if (
        "hello" in msg or
        "hi" in msg or
        "hey" in msg
    ):

        return (
            "Hello 👋 Welcome to the "
            "Library Assistant Bot!"
        )

    # Direct Book Search
    for key, value in books.items():

        if key in msg:
            return f"📚 {value}"

    # Due Date
    if "due" in msg:

        return (
            f"⏰ Your next due date is: "
            f"{due_date}"
        )

    # Library Timings
    elif (
        "open" in msg or
        "timing" in msg or
        "hours" in msg
    ):

        return f"🕒 {opening_hours}"

    # Show All Books
    elif (
        "available" in msg or
        "all books" in msg or
        "books" in msg
    ):

        available_books = "\\n".join(

            [f"• {value}" for value in books.values()]
        )

        return (
            f"📚 Available Books:\\n\\n"
            f"{available_books}"
        )

    # Goodbye
    elif "bye" in msg:

        return (
            "Goodbye 👋 "
            "Have a great day!"
        )

    # Default Reply
    else:

        return (
            "🤖 Sorry, I couldn't find that book.\n\n"
            "Try searching for the book names"
        )


# =========================
# HOME PAGE
# =========================

@app.route("/")
def home():

    return render_template("index.html")


# =========================
# BOT RESPONSE ROUTE
# =========================

@app.route("/get", methods=["POST"])
def get_bot_response():

    user_message = request.form["msg"]

    response = chatbot_response(user_message)

    return jsonify({
        "response": response
    })


# =========================
# RUN APP
# =========================

if __name__ == "__main__":

    app.run(debug=True)