from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Sample responses for chatbot
responses = {
    "emergency": "Emergency services are available 24/7 at our hospital. Please dial 911 for immediate assistance.",
    "room availability": "We have general and private rooms available. Please contact reception at +92-300-1234567 for booking.",
    "visiting hours": "Visiting hours are from 10:00 AM to 8:00 PM daily.",
    "default": "I'm sorry, I didn't understand that. You can ask about 'emergency', 'room availability', or 'visiting hours'."
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.json.get("message").lower()
    
    # Match keywords in user message
    for key in responses:
        if key in user_message:
            return jsonify({"response": responses[key]})
    
    return jsonify({"response": responses["default"]})

if __name__ == "__main__":
    app.run(debug=True)