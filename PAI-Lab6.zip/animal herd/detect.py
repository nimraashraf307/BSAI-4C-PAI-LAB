import cv2
from ultralytics import YOLO

model = YOLO("yolov8n.pt")
ANIMALS = ["cow", "sheep", "horse", "elephant", "dog"]

def detect_animals(image_path):
    img = cv2.imread(image_path)
    results = model(img)
    count = 0

    for r in results:
        for box in r.boxes:
            label = model.names[int(box.cls[0])]
            if label in ANIMALS:
                count += 1
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                cv2.rectangle(img, (x1,y1),(x2,y2),(0,255,0),2)

    herd = count >= 5
    cv2.imwrite("static/output.jpg", img)
    return count, herd
