from flask import Flask, render_template, request
from detect import detect_animals
import os, folium

app = Flask(__name__)

@app.route("/", methods=["GET","POST"])
def index():
    if request.method == "POST":
        img = request.files["image"]
        img.save("static/input.jpg")
        count, herd = detect_animals("static/input.jpg")
        return render_template("result.html", count=count, herd=herd)
    return render_template("index.html")

@app.route("/map")
def map():
    m = folium.Map(location=[31.52,74.35], zoom_start=13)
    folium.Marker([31.52,74.35],
        popup="🐄 Animal Herd Detected",
        icon=folium.Icon(color="red")).add_to(m)
    m.save("templates/map.html")
    return render_template("map.html")

app.run(debug=True)
