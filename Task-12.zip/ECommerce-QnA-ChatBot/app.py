from flask import Flask, render_template, request, jsonify
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import pickle

app = Flask(__name__)

# =========================
# LOAD MODEL
# =========================

model = SentenceTransformer(
    "sentence-transformers/all-MiniLM-L6-v2"
)

# =========================
# LOAD FAISS INDEX
# =========================

index = faiss.read_index(
    "faiss_index/faq_index.faiss"
)

# =========================
# LOAD METADATA
# =========================

with open(
    "faiss_index/faq_metadata.pkl",
    "rb"
) as f:

    data = pickle.load(f)

answers = [item["answer"] for item in data]

# =========================
# CHATBOT FUNCTION
# =========================

def get_response(user_input):

    user_input = user_input.lower().strip()

    # Greetings

    greetings = [
        "hi",
        "hello",
        "hey",
        "salam"
    ]

    if user_input in greetings:

        return (
            "👋 Hello! Welcome to our "
            "E-Commerce Store.\n\n"
            "Ask me about:\n"
            "🛒 Products\n"
            "🚚 Shipping\n"
            "💳 Payments\n"
            "📦 Orders"
        )

    # Casual Questions

    casual = [
        "how are you",
        "how r u",
        "who are you"
    ]

    if user_input in casual:

        return (
            "😊 I'm your E-Commerce Assistant Bot.\n\n"
            "Please ask shopping related questions."
        )

    # CREATE EMBEDDING

    embedding = model.encode([user_input])

    embedding = np.array(
        embedding
    ).astype("float32")

    # SEARCH IN FAISS

    distances, indices = index.search(
        embedding,
        1
    )

    best_match = indices[0][0]

    score = distances[0][0]

    # THRESHOLD

    if score < 1.5:

        return answers[best_match]

    return (
        "🤖 Sorry, I couldn't understand your question.\n\n"
        "Please ask about:\n"
        "🛒 Products\n"
        "🚚 Shipping\n"
        "💳 Payments\n"
        "📦 Orders"
    )

# =========================
# ROUTES
# =========================

@app.route("/")
def home():

    return render_template("index.html")


@app.route("/get", methods=["POST"])
def chatbot():

    user_message = request.form["msg"]

    response = get_response(user_message)

    return jsonify({
        "response": response
    })

# =========================
# RUN APP
# =========================

if __name__ == "__main__":

    app.run(debug=True)