from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import json
import pickle
import os

# =========================
# LOAD FAQ DATA
# =========================

with open("faq_data.json", "r", encoding="utf-8") as f:

    data = json.load(f)

questions = [item["question"] for item in data]

# =========================
# LOAD MODEL
# =========================

model = SentenceTransformer(
    "sentence-transformers/all-MiniLM-L6-v2"
)

# =========================
# CREATE EMBEDDINGS
# =========================

embeddings = model.encode(questions)

embeddings = np.array(
    embeddings
).astype("float32")

# =========================
# CREATE FAISS INDEX
# =========================

dimension = embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)

index.add(embeddings)

# =========================
# CREATE FOLDER
# =========================

os.makedirs(
    "faiss_index",
    exist_ok=True
)

# =========================
# SAVE INDEX
# =========================

faiss.write_index(
    index,
    "faiss_index/faq_index.faiss"
)

# =========================
# SAVE METADATA
# =========================

with open(
    "faiss_index/faq_metadata.pkl",
    "wb"
) as f:

    pickle.dump(data, f)

print("✅ FAISS Index Created Successfully!")