# bot.py

from chatbot import RuleBasedChatbot
from patterns import pairs

def start_chat():
    chatbot = RuleBasedChatbot(pairs)

    print("🤖 Chatbot is running... Type 'exit' to stop.\n")

    while True:
        user_input = input("You: ")

        if user_input.lower() == "exit":
            print("Chatbot: Goodbye! 👋")
            break

        response = chatbot.respond(user_input)
        print("Chatbot:", response)

if __name__ == "__main__":
    start_chat()