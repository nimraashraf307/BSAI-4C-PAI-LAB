# chatbot.py

import nltk
from nltk.chat.util import Chat, reflections

class RuleBasedChatbot:
    def __init__(self, pairs):
        self.chat = Chat(pairs, reflections)

    def respond(self, user_input):
        return self.chat.respond(user_input)