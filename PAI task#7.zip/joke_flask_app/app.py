from flask import Flask, jsonify
import requests

app = Flask(__name__)

@app.route("/")
def home():
    return "Welcome to Random Joke App"

@app.route("/joke")
def get_joke():
    url = "https://official-joke-api.appspot.com/random_joke"
    response = requests.get(url)
    data = response.json()

    return jsonify({
        "setup": data["setup"],
        "punchline": data["punchline"]
    })

if __name__ == "__main__":
    app.run(debug=True)